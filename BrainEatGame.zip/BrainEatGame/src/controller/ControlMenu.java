package controller;

import view.*;

public class ControlMenu {
        public void openMenu(){
        Pemain lv = new Pemain();
        }
  
}
