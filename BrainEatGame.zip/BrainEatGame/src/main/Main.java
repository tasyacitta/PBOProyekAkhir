/*
Raden Rara Lydia Devina Syantasyacitta // Dewi Zunuvi Setiawati
123190086                             // 123190117
Plug IF-C
*/
package main;

import controller.*;

public class Main {
    public static void main(String[] args){
        ControlGame cg= new ControlGame(); //implimentasi polymorphysm
        cg.openMenu();
        
    }
}
