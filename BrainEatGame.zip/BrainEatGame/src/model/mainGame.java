
package model;


import view.*;
import game.Game;
import java.awt.*;
import javax.swing.*;
import java.lang.*;

public class mainGame {
        public void Games(){
       new Game().main(null);
}
}
